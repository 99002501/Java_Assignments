package com.sudarshana.learning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.shabana.learning.Employee;

public class sortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee employee1 = new Employee("Sudarshana","Mysore",111);
        Employee employee2 = new Employee("preetha","Chennai",222);
        Employee employee3 = new Employee("Nikitha","Goregaun",333);
        Employee employee4 = new Employee("Rohan","Mumbai",444);
        Employee employee5 = new Employee("pavithra","Pune",555);
        //add
        ArrayList<Employee> employeeList = new ArrayList<>();
        employeeList.add(employee1);
        employeeList.add(employee2);
        employeeList.add(employee3);
        employeeList.add(employee4);
        employeeList.add(employee5);
        
        for(Employee employ : employeeList) {
        	System.out.println(employ);
        }
        
        Collections.sort(employeeList,new Comparator<Employee>() {

			@Override
			public int compare(Employee e1, Employee e2) {
				// TODO Auto-generated method stub
				return e1.getCity().compareTo(e2.getCity());
			}
        	
        });
        System.out.println("Sorted by city");
       
       for(Employee employ : employeeList) {
       	System.out.println(employ);
       }
        Collections.sort(employeeList,(e1,e2)->{
        	return e1.getEmpId().compareTo(e2.getEmpId());
        });		
        
        System.out.println("Sorted by empId");
        
        for(Employee employ : employeeList) {
        	System.out.println(employ);
        }

	}

}
