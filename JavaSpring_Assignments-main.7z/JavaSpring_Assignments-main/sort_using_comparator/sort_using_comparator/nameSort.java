package com.sudarshana.learning;

import java.util.Comparator;

public class nameSort implements Comparator<Employee>{

	@Override
	public int compare(Employee employ1, Employee employ2) {
		// TODO Auto-generated method stub
		return employ1.getCity().compareTo(employ2.getCity());
	}

}
