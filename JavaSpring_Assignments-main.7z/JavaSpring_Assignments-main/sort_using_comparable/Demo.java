package com.sudarshana.learning;

import java.util.ArrayList;
import java.util.Collections;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee1 = new Employee("Shabana","Mysore",111);
        Employee employee2 = new Employee("John","Chennai",222);
        Employee employee3 = new Employee("Nikitha","Goregaun",333);
        Employee employee4 = new Employee("Rohan","Mumbai",444);
        Employee employee5 = new Employee("Sudarshana","Pune",555);
        //add
        ArrayList<Employee> employeeList = new ArrayList<>();
        employeeList.add(employee1);
        employeeList.add(employee2);
        employeeList.add(employee3);
        employeeList.add(employee4);
        employeeList.add(employee5);
        
        //print
        for(Employee employ : employeeList) {
        	System.out.println(employ);
        }
        Collections.sort(employeeList);
        System.out.println("SortedList");
        for(Employee employ : employeeList) {
        	System.out.println(employ);
        }
        
        
		
		

	}

}
