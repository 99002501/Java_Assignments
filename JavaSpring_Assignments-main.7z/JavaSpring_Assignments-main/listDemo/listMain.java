package com.sudarshana.learning;


import java.util.ArrayList;
import java.util.List;
import java.util.*;

import com.shabana.model.employee;
public class listMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stubList
         List<employee> employeeList = new ArrayList<>();
         //employee employee1 = new employee('Shabana','Mysore',9000.0);
         //employeeList.add(employee1);
         employeeList.add(new employee("siya","noida",90000.0));
         employeeList.add(new employee("john","chennai",70000.0));
         employeeList.add(new employee("nikitha","goregaun",80000.0));
         employeeList.add(new employee("Rohan","mumbai",16000.0));
         employeeList.add(new employee("Sudarshana","pune",18000.0));
         
         System.out.println(employeeList); 
         
         Iterator<employee> it = employeeList.iterator();
         while(it.hasNext()) {
        	 employee emp = it.next();
        	 System.out.println(emp);
        	 }
         System.out.println("......................................");
         for(employee employ:employeeList)
        	 System.out.println(employ);
         System.out.println(".......Reverse Order.........");
         ListIterator<employee> listiter = employeeList.listIterator(employeeList.size());
         while(listiter.hasPrevious()) {
        	 employee employee = listiter.previous();
        	 System.out.print(employee);
         }
	}

}
